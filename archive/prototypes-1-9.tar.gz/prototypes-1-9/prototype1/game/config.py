"""The maps and how the game is drawn. Tunable numbers live in settings.py.

Legend:
    #  wall            .  floor           @  player spawn
    B  notice board    C  cartpole        F  flappy bird terminal
    S  shop counter    N  snake terminal
    T  tribe counter   D  locked door
    E v n  open gates -- where each one goes is in LINKS
    L  lost bag        $  coin bag        *  treasure, contents unknown until opened
    ^  snake pit -- a trap. Never drawn, never in the map view.

Areas are bigger than the window. The view scrolls to follow you; M shows the whole
area at once, but only the parts you have earned the right to see.
"""

# --- display ---------------------------------------------------------------
TILE = 32
VIEW_W = 25          # how many cells fit on screen at once
VIEW_H = 15
HUD_H = 104
FPS = 60

# --- palette ---------------------------------------------------------------
# comfortable daylight white, black ink for structure
PAPER = (247, 245, 240)
INK = (24, 24, 28)
FAINT = (216, 212, 204)
ROAD = (233, 229, 221)
PLAYER = (206, 58, 52)
FOG = (206, 203, 197)
GOLD = (198, 152, 42)
MARK = (176, 62, 150)
PATH = (74, 116, 186)   # the last route A* planned, drawn on the map view
WALKED = (229, 212, 176)  # ...and the ground it actually covered, shaded under it
GOOD = (60, 132, 74)
BAD = (176, 60, 56)
HUMAN = (74, 116, 186)    # your side of the conversation -- so a coached day shows
THINK = (150, 147, 141)   # gemma's reasoning, quieter than what it chose to say

DISPLAY_NAMES = {"plaza": "Plaza", "savana": "Savana", "savana2": "Savana 2"}

# --- maps ------------------------------------------------------------------
# Rows 0-6 are a maze with a coin bag at the far end, entered at (9, 6).
PLAZA = [
    "#####################",
    "#.............#....$#",
    "#######.#.#####.#####",
    "#.......#...........#",
    "#.#################.#",
    "#.............#.....#",
    "#########.###########",
    "#...................#",
    "#..B................#",
    "#...................#",
    "#..###.........###..#",
    "#..#C#.........#F#..#",
    "#..#.#.........#.#..#",
    "#...................D",
    "#.........@.........#",
    "#.......##.##.......#",
    "#.......#.S.#.......#",
    "#.......#####.......#",
    "#####################",
]

# The lost bag is deep in the north-west maze and reveals this area only.
# The south gate at the bottom leads down into Savana 2.
SAVANA = [
    "#################################",
    "#L..#.......#...#...............#",
    "###.#####.#.#.#.#...............#",
    "#.#.....#.#.#.#.#...............#",
    "#.#####.#.#.#.#.#...............#",
    "#.....#.#.#...#.#...^......$....#",
    "#.#.###.#.#####.#...............#",
    "#.#.#...#...#.#.#...............#",
    "#.#.#.#####.#.#.#...............#",
    "#.#.........#...#...............#",
    "###############.########.########",
    "###############.########.########",
    "#...............................#",
    "#...........^...................#",
    "#.....................^.#########",
    "#.......................###^#####",
    "E.......................###...T##",
    "#........^..............###.#####",
    "#...........................^####",
    "#.......................#########",
    "#...............................#",
    "################v################",
]

# No map for this one until you find its lost bag, which also holds a free
# antidote. The snake terminal is the bottom-right corner, behind a pit field.
SAVANA2 = [
    "###############n#################",
    "#L#.#.........#.......#.........#",
    "#.#.#.#.#.#.#.#.#.#.#.#.###.###.#",
    "#.#.........#.#.#.#.#...#.....#.#",
    "#.#####.###.#.#.###.#.#.#.#####.#",
    "#.#.....#...#.#.........#.......#",
    "#.#.###.#.###.#.###.###.#####.#.#",
    "#...#...#.#...#.....#.........#.#",
    "#.#.#.#.#.#.#######.#.###.#.###.#",
    "#...#.....#...#...#.#.#.#.#.....#",
    "###.#.#.#####.#.#.#.#.#.#.#.#.#.#",
    "#.......#...#.#.......#...#.....#",
    "#.#.#####.#.#.#.#.#.#####.#.#.###",
    "########....#.......#......^#...#",
    "####^##########.#.#.#.#.#######.#",
    "###^^^###.....#.....#.#^#.......#",
    "##^^^^^####.###.#####.###.#####.#",
    "#^^^*^^^........#...#^....^.^...#",
    "##^^^^^##.#######.#.#.#.#.....^.#",
    "###^^^###.........#^.....^.^.^..#",
    "####^####################.^...N##",
    "#################################",
]

AREAS = {"plaza": PLAZA, "savana": SAVANA, "savana2": SAVANA2}

# where you land when you walk through each connector
LINKS = {
    ("plaza", (20, 13)): ("savana", (1, 16)),
    ("savana", (0, 16)): ("plaza", (19, 13)),
    ("savana", (16, 21)): ("savana2", (15, 1)),
    ("savana2", (15, 0)): ("savana", (16, 20)),
}

PLAZA_SPAWN = (10, 14)
